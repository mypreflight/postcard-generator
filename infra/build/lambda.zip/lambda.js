"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/lambda.ts
var lambda_exports = {};
__export(lambda_exports, {
  createHandler: () => createHandler,
  handler: () => handler
});
module.exports = __toCommonJS(lambda_exports);
var import_node_crypto2 = require("node:crypto");

// src/errors.ts
var ProviderError = class extends Error {
  static {
    __name(this, "ProviderError");
  }
  constructor(message) {
    super(message);
    this.name = new.target.name;
  }
};
var BadRequestError = class extends ProviderError {
  static {
    __name(this, "BadRequestError");
  }
  status = 400;
  code = "BAD_REQUEST";
};
var UnauthorizedError = class extends ProviderError {
  static {
    __name(this, "UnauthorizedError");
  }
  status = 401;
  code = "UNAUTHORIZED";
  constructor() {
    super("The request did not carry the function secret.");
  }
};
var RouteNotFoundError = class extends ProviderError {
  static {
    __name(this, "RouteNotFoundError");
  }
  status = 404;
  code = "NOT_FOUND";
  constructor(path) {
    super(`Nothing is served at ${path}.`);
  }
};
var PostcardRejectedError = class extends ProviderError {
  static {
    __name(this, "PostcardRejectedError");
  }
  status = 422;
  code = "POSTCARD_REJECTED";
  constructor(reason) {
    super(`OpenAI refused to draw this postcard: ${reason}`);
  }
};
var OpenAiRateLimitedError = class extends ProviderError {
  static {
    __name(this, "OpenAiRateLimitedError");
  }
  status = 429;
  code = "OPENAI_RATE_LIMITED";
  constructor() {
    super("OpenAI is rate limiting image generation.");
  }
};
var OpenAiUnavailableError = class extends ProviderError {
  static {
    __name(this, "OpenAiUnavailableError");
  }
  status = 502;
  code = "OPENAI_UNAVAILABLE";
  constructor() {
    super("OpenAI is unavailable.");
  }
};
var PostcardUnreadableError = class extends ProviderError {
  static {
    __name(this, "PostcardUnreadableError");
  }
  status = 502;
  code = "POSTCARD_UNREADABLE";
  constructor() {
    super("OpenAI answered without a usable image payload.");
  }
};
var SpacesUnavailableError = class extends ProviderError {
  static {
    __name(this, "SpacesUnavailableError");
  }
  status = 502;
  code = "SPACES_UNAVAILABLE";
  constructor() {
    super("The postcard was drawn but could not be stored.");
  }
};
var MisconfiguredError = class extends ProviderError {
  static {
    __name(this, "MisconfiguredError");
  }
  status = 500;
  code = "MISCONFIGURED";
  constructor(reason) {
    super(reason);
  }
};

// src/types.ts
var QUALITIES = ["auto", "low", "medium", "high"];
var FORMATS = ["jpeg", "png"];
var CONTINENTS = [
  "Africa",
  "Antarctica",
  "Asia",
  "Europe",
  "North America",
  "Oceania",
  "South America"
];
var CONTENT_TYPES = {
  jpeg: "image/jpeg",
  png: "image/png"
};
var EXTENSIONS = {
  jpeg: "jpg",
  png: "png"
};

// src/request.ts
var MAX_CITY_LENGTH = 64;
var MAX_CITY_WORDS = 5;
var MAX_COUNTRY_LENGTH = 64;
var MAX_COUNTRY_WORDS = 8;
var CITY_PATTERN = /^[\p{Script=Latin}\p{Mark}0-9 .'’-]+$/u;
var COUNTRY_PATTERN = /^[\p{Script=Latin}\p{Mark}0-9 .,'’&()-]+$/u;
var UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
var SIZE_PATTERN = /^(\d{3,4})x(\d{3,4})$/;
var SIZE_STEP = 16;
var MIN_SIDE = 256;
var MAX_SIDE = 3840;
var MAX_PIXELS = 3840 * 2160;
var MAX_ASPECT_RATIO = 3;
function parseCity(value) {
  const city = (value ?? "").trim();
  if (!city) {
    throw new BadRequestError("Parameter city is required.");
  }
  if (city.length > MAX_CITY_LENGTH) {
    throw new BadRequestError(`Parameter city may not exceed ${MAX_CITY_LENGTH} characters.`);
  }
  if (!CITY_PATTERN.test(city)) {
    throw new BadRequestError("Parameter city may only contain Latin letters, digits, spaces, apostrophes and dots.");
  }
  if (city.split(/\s+/).length > MAX_CITY_WORDS) {
    throw new BadRequestError(
      `Parameter city is a city name, not a sentence, so it may not exceed ${MAX_CITY_WORDS} words.`
    );
  }
  return city;
}
__name(parseCity, "parseCity");
function parseCountry(value) {
  const country = (value ?? "").trim();
  if (!country) {
    throw new BadRequestError("Parameter country is required.");
  }
  if (country.length > MAX_COUNTRY_LENGTH) {
    throw new BadRequestError(`Parameter country may not exceed ${MAX_COUNTRY_LENGTH} characters.`);
  }
  if (!COUNTRY_PATTERN.test(country)) {
    throw new BadRequestError(
      "Parameter country may only contain Latin letters, digits, spaces, apostrophes, dots, commas, ampersands and brackets."
    );
  }
  if (country.split(/\s+/).length > MAX_COUNTRY_WORDS) {
    throw new BadRequestError(
      `Parameter country is a country name, not a sentence, so it may not exceed ${MAX_COUNTRY_WORDS} words.`
    );
  }
  return country;
}
__name(parseCountry, "parseCountry");
function parseContinent(value) {
  const continent = (value ?? "").trim();
  if (!continent) {
    throw new BadRequestError("Parameter continent is required.");
  }
  const known = CONTINENTS.find((candidate) => candidate.toLowerCase() === continent.toLowerCase());
  if (!known) {
    throw new BadRequestError(`Parameter continent must be one of ${CONTINENTS.join(", ")}, got "${continent}".`);
  }
  return known;
}
__name(parseContinent, "parseContinent");
function parseUuid(value) {
  const uuid = (value ?? "").trim();
  if (!uuid) {
    throw new BadRequestError("Parameter uuid is required.");
  }
  if (!UUID_PATTERN.test(uuid)) {
    throw new BadRequestError(`Parameter uuid must be a uuid, got "${uuid}".`);
  }
  return uuid.toLowerCase();
}
__name(parseUuid, "parseUuid");
function parseSize(value, fallback) {
  const size = (value ?? "").trim() || fallback;
  const match = SIZE_PATTERN.exec(size);
  if (!match) {
    throw new BadRequestError(`Parameter size must look like 1152x1536, got "${size}".`);
  }
  const width = Number(match[1]);
  const height = Number(match[2]);
  if (width % SIZE_STEP !== 0 || height % SIZE_STEP !== 0) {
    throw new BadRequestError(`Parameter size must have both sides divisible by ${SIZE_STEP}, got "${size}".`);
  }
  if (width < MIN_SIDE || height < MIN_SIDE || width > MAX_SIDE || height > MAX_SIDE) {
    throw new BadRequestError(
      `Parameter size must keep both sides between ${MIN_SIDE} and ${MAX_SIDE}, got "${size}".`
    );
  }
  if (width * height > MAX_PIXELS) {
    throw new BadRequestError(`Parameter size may not exceed ${MAX_PIXELS} pixels, got "${size}".`);
  }
  const ratio = Math.max(width / height, height / width);
  if (ratio > MAX_ASPECT_RATIO) {
    throw new BadRequestError(`Parameter size must stay within a 1:3 to 3:1 aspect ratio, got "${size}".`);
  }
  return size;
}
__name(parseSize, "parseSize");
function parseQuality(value, fallback) {
  const quality = (value ?? "").trim().toLowerCase() || fallback;
  if (!QUALITIES.includes(quality)) {
    throw new BadRequestError(`Parameter quality must be one of ${QUALITIES.join(", ")}, got "${quality}".`);
  }
  return quality;
}
__name(parseQuality, "parseQuality");
function parseFormat(value, fallback) {
  const format2 = (value ?? "").trim().toLowerCase() || fallback;
  if (!FORMATS.includes(format2)) {
    throw new BadRequestError(`Parameter format must be one of ${FORMATS.join(", ")}, got "${format2}".`);
  }
  return format2;
}
__name(parseFormat, "parseFormat");
function parseRequest(params, defaults) {
  return {
    city: parseCity(params.city),
    country: parseCountry(params.country),
    continent: parseContinent(params.continent),
    uuid: parseUuid(params.uuid),
    size: defaults.size,
    quality: defaults.quality,
    format: defaults.format,
    compression: defaults.compression
  };
}
__name(parseRequest, "parseRequest");

// src/config.ts
var FALLBACK_SIZE = "1152x1536";
var FALLBACK_QUALITY = "high";
var FALLBACK_FORMAT = "jpeg";
var FALLBACK_COMPRESSION = 80;
var FALLBACK_PREFIX = "postcards/";
function readCompression() {
  const raw = (process.env.POSTCARD_COMPRESSION ?? "").trim();
  if (!raw) {
    return FALLBACK_COMPRESSION;
  }
  const compression = Number(raw);
  if (!Number.isInteger(compression) || compression < 1 || compression > 100) {
    throw new Error(`POSTCARD_COMPRESSION must be an integer between 1 and 100, got "${raw}".`);
  }
  return compression;
}
__name(readCompression, "readCompression");
function readDefaults() {
  return {
    size: parseSize(process.env.POSTCARD_SIZE, FALLBACK_SIZE),
    quality: parseQuality(process.env.POSTCARD_QUALITY, FALLBACK_QUALITY),
    format: parseFormat(process.env.POSTCARD_FORMAT, FALLBACK_FORMAT),
    compression: readCompression()
  };
}
__name(readDefaults, "readDefaults");
function required(name) {
  const value = (process.env[name] ?? "").trim();
  if (!value) {
    throw new MisconfiguredError(`${name} must be set for the postcard to be stored.`);
  }
  return value;
}
__name(required, "required");
function readPrefix(name) {
  const raw = (process.env[name] ?? FALLBACK_PREFIX).trim().replace(/^\/+/, "");
  if (!raw) {
    return "";
  }
  return raw.endsWith("/") ? raw : `${raw}/`;
}
__name(readPrefix, "readPrefix");
function readAwsCredentials() {
  const accessKeyId = (process.env.AWS_ACCESS_KEY_ID ?? "").trim();
  const secretAccessKey = (process.env.AWS_SECRET_ACCESS_KEY ?? "").trim();
  const sessionToken = (process.env.AWS_SESSION_TOKEN ?? "").trim();
  if (!accessKeyId || !secretAccessKey) {
    throw new MisconfiguredError(
      "AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY must be set for the function to reach AWS."
    );
  }
  return sessionToken ? { accessKeyId, secretAccessKey, sessionToken } : { accessKeyId, secretAccessKey };
}
__name(readAwsCredentials, "readAwsCredentials");
function readAwsRegion() {
  return (process.env.AWS_REGION ?? "").trim();
}
__name(readAwsRegion, "readAwsRegion");
function readS3Options() {
  const bucket = required("S3_BUCKET");
  const region = (process.env.S3_REGION ?? "").trim() || readAwsRegion();
  if (!region) {
    throw new MisconfiguredError("S3_REGION or AWS_REGION must be set for the postcard to be stored.");
  }
  const endpoint = (process.env.S3_ENDPOINT ?? "").trim() || `https://${bucket}.s3.${region}.amazonaws.com`;
  return {
    endpoint,
    publicBaseUrl: (process.env.S3_PUBLIC_BASE_URL ?? "").trim() || endpoint,
    region,
    prefix: readPrefix("S3_PREFIX"),
    credentials: readAwsCredentials
  };
}
__name(readS3Options, "readS3Options");
function readLambdaInvokerOptions() {
  const functionName = (process.env.AWS_LAMBDA_FUNCTION_NAME ?? "").trim();
  const region = readAwsRegion();
  if (!functionName || !region) {
    return null;
  }
  return {
    endpoint: (process.env.LAMBDA_ENDPOINT ?? "").trim() || `https://lambda.${region}.amazonaws.com`,
    region,
    functionName,
    credentials: readAwsCredentials
  };
}
__name(readLambdaInvokerOptions, "readLambdaInvokerOptions");

// src/logger.ts
var SEVERITY = {
  verbose: 10,
  debug: 20,
  log: 30,
  warn: 40,
  error: 50,
  fatal: 60
};
var DEFAULT_LEVEL = "log";
var PREFIX = "Postcard";
var plain = /* @__PURE__ */ __name((text) => text, "plain");
function ansi(open) {
  return (text) => `\x1B[${open}m${text}\x1B[39m`;
}
__name(ansi, "ansi");
var COLORS = {
  verbose: ansi("96"),
  debug: ansi("95"),
  log: ansi("32"),
  warn: ansi("33"),
  error: ansi("31"),
  fatal: /* @__PURE__ */ __name((text) => `\x1B[1m${text}\x1B[0m`, "fatal")
};
var CONTEXT_COLOR = ansi("38;5;3");
function isLevel(value) {
  return value in SEVERITY;
}
__name(isLevel, "isLevel");
function threshold() {
  const configured = (process.env.LOG_LEVEL ?? "").toLowerCase();
  return SEVERITY[isLevel(configured) ? configured : DEFAULT_LEVEL];
}
__name(threshold, "threshold");
function colored() {
  return process.stdout.isTTY === true && !process.env.NO_COLOR;
}
__name(colored, "colored");
function timestamp() {
  return (/* @__PURE__ */ new Date()).toLocaleString("en-US", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "numeric",
    minute: "numeric",
    second: "numeric"
  });
}
__name(timestamp, "timestamp");
function format(level, context, message) {
  const paint = colored() ? COLORS[level] : plain;
  const contextPaint = colored() ? CONTEXT_COLOR : plain;
  const pid = paint(`[${PREFIX}] ${process.pid}  - `);
  const label = paint(level.toUpperCase().padStart(7, " "));
  return `${pid}${timestamp()} ${label} ${contextPaint(`[${context}] `)}${paint(message)}`;
}
__name(format, "format");
function write(level, context, message, stack) {
  if (SEVERITY[level] < threshold()) {
    return;
  }
  const stream = level === "error" || level === "fatal" ? process.stderr : process.stdout;
  stream.write(`${format(level, context, message)}
${stack ? `${stack}
` : ""}`);
}
__name(write, "write");
function describeError(error, depth = 3) {
  if (!(error instanceof Error)) {
    try {
      return `Non-error thrown: ${JSON.stringify(error)}`;
    } catch {
      return `Non-error thrown: ${String(error)}`;
    }
  }
  const head = `${error.name}: ${error.message}`;
  if (depth <= 1 || error.cause === void 0 || error.cause === null) {
    return head;
  }
  return `${head} (caused by: ${describeError(error.cause, depth - 1)})`;
}
__name(describeError, "describeError");
function stackOf(error) {
  return error instanceof Error ? error.stack : void 0;
}
__name(stackOf, "stackOf");
var Logger = class {
  constructor(context) {
    this.context = context;
  }
  context;
  static {
    __name(this, "Logger");
  }
  verbose(message) {
    write("verbose", this.context, message);
  }
  debug(message) {
    write("debug", this.context, message);
  }
  log(message) {
    write("log", this.context, message);
  }
  warn(message) {
    write("warn", this.context, message);
  }
  error(message, stack) {
    write("error", this.context, message, stack);
  }
  fatal(message, stack) {
    write("fatal", this.context, message, stack);
  }
};

// src/sigv4.ts
var import_node_crypto = require("node:crypto");
var ALGORITHM = "AWS4-HMAC-SHA256";
var TERMINATOR = "aws4_request";
var SINGLE_ENCODED_SERVICE = "s3";
function sha256Hex(payload) {
  return (0, import_node_crypto.createHash)("sha256").update(payload).digest("hex");
}
__name(sha256Hex, "sha256Hex");
function hmac(key, data) {
  return (0, import_node_crypto.createHmac)("sha256", key).update(data).digest();
}
__name(hmac, "hmac");
function encodeRfc3986(value) {
  return encodeURIComponent(value).replace(/[!'()*]/g, (char) => `%${char.charCodeAt(0).toString(16).toUpperCase()}`);
}
__name(encodeRfc3986, "encodeRfc3986");
function canonicalPath(pathname, service) {
  if (service === SINGLE_ENCODED_SERVICE) {
    return pathname;
  }
  return pathname.split("/").map((segment) => encodeRfc3986(segment)).join("/");
}
__name(canonicalPath, "canonicalPath");
function compare(a, b) {
  if (a === b) {
    return 0;
  }
  return a < b ? -1 : 1;
}
__name(compare, "compare");
function canonicalQuery(search) {
  return [...search.entries()].map(([key, value]) => [encodeRfc3986(key), encodeRfc3986(value)]).sort(([keyA, valueA], [keyB, valueB]) => compare(keyA, keyB) || compare(valueA, valueB)).map(([key, value]) => `${key}=${value}`).join("&");
}
__name(canonicalQuery, "canonicalQuery");
function timestamp2(now) {
  return `${now.toISOString().replace(/[-:]/g, "").slice(0, 15)}Z`;
}
__name(timestamp2, "timestamp");
function signingKey(secretAccessKey, date, region, service) {
  const kDate = hmac(`AWS4${secretAccessKey}`, date);
  const kRegion = hmac(kDate, region);
  const kService = hmac(kRegion, service);
  return hmac(kService, TERMINATOR);
}
__name(signingKey, "signingKey");
function signRequest(request, credentials, now = /* @__PURE__ */ new Date()) {
  const { host, pathname, searchParams } = new URL(request.url);
  const stamp = timestamp2(now);
  const date = stamp.slice(0, 8);
  const headers = {};
  for (const [name, value] of Object.entries(request.headers)) {
    headers[name.toLowerCase()] = value;
  }
  headers.host = host;
  headers["x-amz-date"] = stamp;
  if (credentials.sessionToken) {
    headers["x-amz-security-token"] = credentials.sessionToken;
  }
  const payloadHash = headers["x-amz-content-sha256"] ?? sha256Hex(request.body);
  const names = Object.keys(headers).sort();
  const canonicalHeaders = names.map((name) => `${name}:${headers[name].trim()}
`).join("");
  const signedHeaders = names.join(";");
  const canonicalRequest = [
    request.method.toUpperCase(),
    canonicalPath(pathname, request.service),
    canonicalQuery(searchParams),
    canonicalHeaders,
    signedHeaders,
    payloadHash
  ].join("\n");
  const scope = `${date}/${request.region}/${request.service}/${TERMINATOR}`;
  const stringToSign = [ALGORITHM, stamp, scope, sha256Hex(canonicalRequest)].join("\n");
  const key = signingKey(credentials.secretAccessKey, date, request.region, request.service);
  const signature = hmac(key, stringToSign).toString("hex");
  const signed = {};
  for (const name of names) {
    signed[name] = headers[name];
  }
  return {
    ...signed,
    Authorization: `${ALGORITHM} Credential=${credentials.accessKeyId}/${scope}, SignedHeaders=${signedHeaders}, Signature=${signature}`
  };
}
__name(signRequest, "signRequest");

// src/invoker.ts
var SERVICE = "lambda";
var API_VERSION = "2015-03-31";
var TIMEOUT_MS = 1e4;
var ACCEPTED = 202;
var DRAW_EVENT = "draw";
var LambdaInvoker = class _LambdaInvoker {
  constructor(options) {
    this.options = options;
    const endpoint = options.endpoint.replace(/\/+$/, "");
    const name = encodeURIComponent(options.functionName);
    this.url = `${endpoint}/${API_VERSION}/functions/${name}/invocations`;
  }
  options;
  static {
    __name(this, "LambdaInvoker");
  }
  logger = new Logger(_LambdaInvoker.name);
  url;
  async schedule(params) {
    const event = { kind: DRAW_EVENT, params };
    const body = JSON.stringify(event);
    const headers = signRequest(
      {
        method: "POST",
        url: this.url,
        region: this.options.region,
        service: SERVICE,
        headers: {
          "content-type": "application/json",
          "x-amz-invocation-type": "Event"
        },
        body
      },
      this.options.credentials()
    );
    let response;
    try {
      response = await fetch(this.url, {
        method: "POST",
        headers,
        body,
        signal: AbortSignal.timeout(TIMEOUT_MS)
      });
    } catch (error) {
      throw new Error(`could not reach ${this.url}: ${describeError(error)}`);
    }
    if (response.status !== ACCEPTED) {
      const type = response.headers.get("x-amzn-errortype");
      throw new Error(`${this.url} answered ${response.status}${type ? ` ${type}` : ""}`);
    }
    this.logger.log(`Handed the render to an asynchronous invocation of ${this.options.functionName}.`);
    return "activation";
  }
};

// src/bucket.ts
var TIMEOUT_MS2 = 6e4;
var RETRIES = 1;
var BACKOFF_MS = 500;
var delay = /* @__PURE__ */ __name((ms) => new Promise((resolve) => setTimeout(resolve, ms)), "delay");
var BucketClient = class {
  constructor(location, provider) {
    this.provider = provider;
    this.endpoint = location.endpoint.replace(/\/+$/, "");
    this.publicBaseUrl = location.publicBaseUrl.replace(/\/+$/, "");
    this.prefix = location.prefix;
  }
  provider;
  static {
    __name(this, "BucketClient");
  }
  logger = new Logger(this.constructor.name);
  endpoint;
  publicBaseUrl;
  prefix;
  /**
   * Where an object will land, known before it is drawn because the caller names it. The upload is signed
   * against the bucket endpoint, while readers are pointed at the public base url, which may be a CNAME.
   */
  locate(name) {
    const key = `${this.prefix}${name}`;
    return { key, url: `${this.publicBaseUrl}/${encodeKey(key)}` };
  }
  async store(name, body, contentType) {
    const { key, url } = this.locate(name);
    const uploadUrl = `${this.endpoint}/${encodeKey(key)}`;
    const startedAt = Date.now();
    const response = await this.putWithRetry(uploadUrl, body, contentType);
    if (!response.ok) {
      this.logger.error(`${this.provider} answered ${response.status} for ${key}: ${await this.readBody(response)}`);
      throw new SpacesUnavailableError();
    }
    this.logger.log(`Stored ${key} as ${body.byteLength} bytes in ${Date.now() - startedAt}ms.`);
    return { key, url };
  }
  async readBody(response) {
    try {
      return (await response.text()).slice(0, 500);
    } catch {
      return "no body";
    }
  }
  async putWithRetry(url, body, contentType) {
    for (let attempt = 0; attempt <= RETRIES; attempt++) {
      const headers = this.sign(url, body, contentType);
      try {
        return await fetch(url, {
          method: "PUT",
          headers,
          body: new Uint8Array(body),
          signal: AbortSignal.timeout(TIMEOUT_MS2)
        });
      } catch (error) {
        if (attempt === RETRIES) {
          this.logger.error(`Could not reach ${url} in ${RETRIES + 1} attempts: ${describeError(error)}`);
          throw new SpacesUnavailableError();
        }
        const backoff = BACKOFF_MS * 2 ** attempt;
        this.logger.warn(
          `Attempt ${attempt + 1} to reach ${url} failed: ${describeError(error)}. Retrying in ${backoff}ms.`
        );
        await delay(backoff);
      }
    }
    throw new SpacesUnavailableError();
  }
};
function encodeKey(key) {
  return key.split("/").map((segment) => encodeRfc3986(segment)).join("/");
}
__name(encodeKey, "encodeKey");

// src/s3.ts
var SERVICE2 = "s3";
var S3Client = class extends BucketClient {
  static {
    __name(this, "S3Client");
  }
  region;
  credentials;
  constructor(options) {
    super(options, "S3");
    this.region = options.region;
    this.credentials = options.credentials;
  }
  sign(url, body, contentType) {
    return signRequest(
      {
        method: "PUT",
        url,
        region: this.region,
        service: SERVICE2,
        headers: {
          "content-type": contentType,
          "x-amz-content-sha256": sha256Hex(body)
        },
        body
      },
      this.credentials()
    );
  }
};

// src/client.ts
var GENERATIONS_PATH = "/v1/images/generations";
var TIMEOUT_MS3 = 24e4;
var RETRIES2 = 1;
var BACKOFF_MS2 = 1e3;
var CACHE_TTL_MS = 864e5;
var CACHE_MAX_ENTRIES = 8;
var REJECTION_CODES = ["moderation_blocked", "content_policy_violation", "invalid_prompt"];
var delay2 = /* @__PURE__ */ __name((ms) => new Promise((resolve) => setTimeout(resolve, ms)), "delay");
var OpenAiClient = class _OpenAiClient {
  static {
    __name(this, "OpenAiClient");
  }
  logger = new Logger(_OpenAiClient.name);
  baseUrl;
  apiKey;
  model;
  cache = /* @__PURE__ */ new Map();
  constructor(options) {
    this.baseUrl = options.baseUrl.replace(/\/+$/, "");
    this.apiKey = options.apiKey;
    this.model = options.model;
  }
  async draw(request, prompt) {
    return this.cached(cacheKey(request), async () => {
      const startedAt = Date.now();
      const response = await this.post(prompt, request);
      const image = await this.readImage(response);
      this.logger.log(
        `Drew ${request.city}, ${request.country} as ${image.bytes} ${request.format} bytes in ${Date.now() - startedAt}ms.`
      );
      return image;
    });
  }
  async cached(key, produce) {
    const entry = this.cache.get(key);
    if (entry && entry.expiresAt > Date.now()) {
      this.logger.debug(`Serving ${key} from cache.`);
      return entry.value;
    }
    const value = await produce();
    this.remember(key, value);
    return value;
  }
  remember(key, value) {
    this.cache.delete(key);
    while (this.cache.size >= CACHE_MAX_ENTRIES) {
      const oldest = this.cache.keys().next().value;
      if (oldest === void 0) {
        break;
      }
      this.cache.delete(oldest);
    }
    this.cache.set(key, { value, expiresAt: Date.now() + CACHE_TTL_MS });
  }
  async post(prompt, request) {
    const payload = {
      model: this.model,
      prompt,
      n: 1,
      size: request.size,
      quality: request.quality,
      background: "opaque",
      output_format: request.format
    };
    if (request.format === "jpeg") {
      payload.output_compression = request.compression;
    }
    const response = await this.fetchWithRetry(payload);
    if (!response.ok) {
      await this.raiseFor(response);
    }
    return response;
  }
  async raiseFor(response) {
    const body = await this.readErrorBody(response);
    const code = body.error?.code ?? body.error?.type ?? "unknown";
    const message = body.error?.message ?? "no message";
    if (response.status === 429) {
      this.logger.warn(`OpenAI rate limited image generation: ${message}`);
      throw new OpenAiRateLimitedError();
    }
    if (response.status === 400 && REJECTION_CODES.includes(code)) {
      this.logger.warn(`OpenAI rejected the prompt with ${code}: ${message}`);
      throw new PostcardRejectedError(message);
    }
    this.logger.error(`OpenAI answered ${response.status} ${code}: ${message}`);
    throw new OpenAiUnavailableError();
  }
  async readErrorBody(response) {
    try {
      return JSON.parse(await response.text());
    } catch {
      return {};
    }
  }
  async readImage(response) {
    let body;
    try {
      body = await response.json();
    } catch (error) {
      this.logger.warn(`Could not read the OpenAI response: ${describeError(error)}`);
      throw new PostcardUnreadableError();
    }
    const base64 = body.data?.[0]?.b64_json;
    if (!base64) {
      this.logger.warn("OpenAI answered without b64_json image data.");
      throw new PostcardUnreadableError();
    }
    return { base64, bytes: decodedBytes(base64) };
  }
  async fetchWithRetry(payload) {
    const url = `${this.baseUrl}${GENERATIONS_PATH}`;
    for (let attempt = 0; attempt <= RETRIES2; attempt++) {
      try {
        return await fetch(url, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${this.apiKey}`
          },
          body: JSON.stringify(payload),
          signal: AbortSignal.timeout(TIMEOUT_MS3)
        });
      } catch (error) {
        if (attempt === RETRIES2) {
          this.logger.error(`Could not reach ${url} in ${RETRIES2 + 1} attempts: ${describeError(error)}`);
          throw new OpenAiUnavailableError();
        }
        const backoff = BACKOFF_MS2 * 2 ** attempt;
        this.logger.warn(
          `Attempt ${attempt + 1} to reach ${url} failed: ${describeError(error)}. Retrying in ${backoff}ms.`
        );
        await delay2(backoff);
      }
    }
    throw new OpenAiUnavailableError();
  }
};
function decodedBytes(base64) {
  const padding = base64.endsWith("==") ? 2 : base64.endsWith("=") ? 1 : 0;
  return base64.length / 4 * 3 - padding;
}
__name(decodedBytes, "decodedBytes");
function cacheKey(request) {
  return [
    request.city.toLowerCase(),
    request.country.toLowerCase(),
    request.continent.toLowerCase(),
    request.size,
    request.quality,
    request.format,
    request.format === "jpeg" ? request.compression : "-"
  ].join("|");
}
__name(cacheKey, "cacheKey");

// src/prompt.ts
var TEMPLATE = [
  "Full-bleed vertical 3:4 minimalist flat-vector travel art poster for TARGET_CITY. Design an authentic, bespoke travel poster capturing the distinct visual identity of TARGET_CITY, avoiding generic postcard templates. The illustration must extend edge-to-edge across the entire canvas with no outer white border, no frame, no margin, and no mockup presentation.",
  "PLACE: TARGET_CITY is the city of that name in TARGET_COUNTRY, on TARGET_CONTINENT. Use TARGET_COUNTRY and TARGET_CONTINENT only to settle which city is meant where the name is shared with cities elsewhere, and to ground the regional architecture, vegetation, terrain, climate and quality of light in the correct part of the world. They are context for the illustration and never subject matter of their own.",
  "SCENE & COMPOSITION: Analyze the authentic geography and urban fabric of TARGET_CITY to construct a natural, city-specific composition from a fitting viewpoint. Ground the scene with one defining local architectural landmark or iconic skyline element as the primary focal point, supported by 2 to 4 subtle environmental characteristics inherently typical of the location's native surroundings and infrastructure.",
  "FIGURES & ACTIVITY: Integrate 3 to 6 small-scale, understated human figures naturally blended into the background. Each person engages in an authentic, everyday local activity suited to the setting, without drawing focus as a central hero character.",
  "TYPOGRAPHY: Set the exact city name TARGET_CITY in uppercase in the upper-left corner within generous clean negative space. Keep typography restrained, clean, and editorial, ensuring it never overpowers the artwork. All text and lettering must be in English. The city name is the only text anywhere in the image: never render TARGET_COUNTRY or TARGET_CONTINENT as text, as a flag, as an emblem or as a country code, and add no captions, subtitles or other lettering of any kind.",
  "ART STYLE & COLOR PALETTE: Modern Japanese stationery aesthetic, luxury vinyl sticker art, clean uniform monoline vector outlines, flat solid color fills, and geometric simplicity without gradients, paper textures, or heavy drop shadows. Color system is dominated by pale powder blue, soft sky blue, and mist tones, balanced with warm ivory, cream, muted sage, and neutral architectural tones. Use delicate blush or dusty rose exclusively for tiny accents.",
  "MOOD & CONSTRAINTS: Serene, airy, balanced, and contemporary. Clean graphic layout with generous breathing room. Full-bleed flat illustration only\u2014strictly no white borders, no photorealism, no 3D rendering, no painterly textures, no watercolor bleed, and no cluttered collage layouts."
].join(" ");
function buildPrompt(city, country, continent) {
  return `TARGET_CITY = "${city}" TARGET_COUNTRY = "${country}" TARGET_CONTINENT = "${continent}" ${TEMPLATE}`;
}
__name(buildPrompt, "buildPrompt");

// src/handler.ts
var ACCEPTED2 = 202;
var logger = new Logger("PostcardHandler");
function describeRequest(params) {
  return [
    `city=${params.city ?? "-"}`,
    `country=${params.country ?? "-"}`,
    `continent=${params.continent ?? "-"}`,
    `uuid=${params.uuid ?? "-"}`
  ].join(" ");
}
__name(describeRequest, "describeRequest");
function isBackgroundActivation(params) {
  return params.background === true || params.background === "true";
}
__name(isBackgroundActivation, "isBackgroundActivation");
function objectName(request) {
  return `${request.uuid}.${EXTENSIONS[request.format]}`;
}
__name(objectName, "objectName");
async function drawAndStore(client, store, request) {
  const prompt = buildPrompt(request.city, request.country, request.continent);
  const image = await client.draw(request, prompt);
  const contentType = CONTENT_TYPES[request.format];
  const stored = await store.store(objectName(request), Buffer.from(image.base64, "base64"), contentType);
  return {
    city: request.city,
    country: request.country,
    continent: request.continent,
    uuid: request.uuid,
    model: client.model,
    size: request.size,
    quality: request.quality,
    format: request.format,
    contentType,
    bytes: image.bytes,
    prompt,
    key: stored.key,
    url: stored.url
  };
}
__name(drawAndStore, "drawAndStore");
async function accept(scheduler, store, request) {
  const { key, url } = store.locate(objectName(request));
  let handoff;
  try {
    handoff = await scheduler.schedule({
      city: request.city,
      country: request.country,
      continent: request.continent,
      uuid: request.uuid,
      background: true
    });
  } catch (error) {
    const refused = describeError(error);
    logger.warn(
      `Could not hand ${request.city}, ${request.country} to a background activation, so it is drawn while the caller waits: ${refused}`
    );
    return { refused };
  }
  logger.log(`Accepted ${request.city}, ${request.country} over ${handoff}. The art will appear at ${key}.`);
  return {
    accepted: {
      statusCode: ACCEPTED2,
      body: {
        status: "accepted",
        city: request.city,
        country: request.country,
        continent: request.continent,
        uuid: request.uuid,
        size: request.size,
        quality: request.quality,
        format: request.format,
        key,
        url,
        handoff: { mode: handoff }
      }
    }
  };
}
__name(accept, "accept");
async function handleRequest(client, store, params, defaults, scheduler = null) {
  const startedAt = Date.now();
  try {
    const request = parseRequest(params, defaults);
    let refused = null;
    if (scheduler && !isBackgroundActivation(params)) {
      const acceptance = await accept(scheduler, store, request);
      if ("accepted" in acceptance) {
        return acceptance.accepted;
      }
      refused = acceptance.refused;
    }
    const postcard = await drawAndStore(client, store, request);
    logger.log(`Served ${describeRequest(params)} in ${Date.now() - startedAt}ms.`);
    return {
      statusCode: 200,
      body: refused ? { ...postcard, handoff: { mode: "inline", reason: refused } } : postcard
    };
  } catch (error) {
    if (error instanceof ProviderError) {
      logger.warn(
        `Request ${describeRequest(params)} failed after ${Date.now() - startedAt}ms with ${error.status} ${error.code}: ${error.message}`
      );
      return {
        statusCode: error.status,
        body: {
          error: {
            code: error.code,
            message: error.message,
            status: error.status
          }
        }
      };
    }
    logger.error(
      `Request ${describeRequest(params)} crashed after ${Date.now() - startedAt}ms: ${describeError(error)}`,
      stackOf(error)
    );
    return {
      statusCode: 500,
      body: {
        error: {
          code: "INTERNAL_ERROR",
          message: "Postcard generation failed.",
          status: 500
        }
      }
    };
  }
}
__name(handleRequest, "handleRequest");

// src/service.ts
var DEFAULT_BASE_URL = "https://api.openai.com";
var DEFAULT_MODEL = "gpt-image-2";
var PostcardService = class {
  constructor(wiring) {
    this.wiring = wiring;
    this.logger = new Logger(wiring.context);
  }
  wiring;
  static {
    __name(this, "PostcardService");
  }
  logger;
  client;
  store;
  defaults;
  scheduler;
  reset() {
    this.client = void 0;
    this.store = void 0;
    this.defaults = void 0;
    this.scheduler = void 0;
  }
  async serve(args) {
    let resolved;
    try {
      resolved = {
        client: this.resolveClient(),
        store: this.resolveStore(),
        defaults: this.resolveDefaults(),
        scheduler: this.resolveScheduler()
      };
    } catch (error) {
      const status = error instanceof ProviderError ? error.status : 500;
      const code = error instanceof ProviderError ? error.code : "MISCONFIGURED";
      this.logger.error(`Cannot serve postcards: ${describeError(error)}`, stackOf(error));
      return {
        statusCode: status,
        body: { error: { code, message: describeError(error), status } }
      };
    }
    return handleRequest(resolved.client, resolved.store, args ?? {}, resolved.defaults, resolved.scheduler);
  }
  resolveClient() {
    if (!this.client) {
      const baseUrl = process.env.OPENAI_API_HOST ?? DEFAULT_BASE_URL;
      const model = process.env.POSTCARD_MODEL ?? DEFAULT_MODEL;
      this.client = new OpenAiClient({
        baseUrl,
        apiKey: process.env.OPENAI_API_KEY ?? "",
        model
      });
      this.logger.log(`Cold start. Drawing postcards with ${model} at ${baseUrl}.`);
    }
    return this.client;
  }
  resolveStore() {
    if (!this.store) {
      this.store = this.wiring.store();
    }
    return this.store;
  }
  resolveDefaults() {
    if (!this.defaults) {
      this.defaults = readDefaults();
    }
    return this.defaults;
  }
  resolveScheduler() {
    if (this.scheduler === void 0) {
      this.scheduler = this.wiring.scheduler();
    }
    return this.scheduler;
  }
};

// src/lambda.ts
var CONTEXT = "PostcardLambda";
var ROUTE = "/city";
var SECRET_HEADER = "x-require-whisk-auth";
var logger2 = new Logger(CONTEXT);
function createS3() {
  const options = readS3Options();
  const store = new S3Client(options);
  logger2.log(`Storing postcards at ${options.endpoint}/${options.prefix}.`);
  return store;
}
__name(createS3, "createS3");
function createInvoker() {
  const options = readLambdaInvokerOptions();
  logger2.log(
    options ? `Renders are handed to asynchronous invocations of ${options.functionName}.` : "No function to invoke, so renders happen while the caller waits."
  );
  return options ? new LambdaInvoker(options) : null;
}
__name(createInvoker, "createInvoker");
function isRecord(value) {
  return typeof value === "object" && value !== null;
}
__name(isRecord, "isRecord");
function isDrawEvent(event) {
  return isRecord(event) && event.kind === DRAW_EVENT && isRecord(event.params);
}
__name(isDrawEvent, "isDrawEvent");
function isFunctionUrlEvent(event) {
  if (!isRecord(event) || typeof event.rawPath !== "string" || !isRecord(event.requestContext)) {
    return false;
  }
  const http = event.requestContext.http;
  return isRecord(http) && typeof http.method === "string";
}
__name(isFunctionUrlEvent, "isFunctionUrlEvent");
function respond({ statusCode, body }) {
  return {
    statusCode,
    headers: { "Content-Type": "application/json" },
    body: typeof body === "string" ? body : JSON.stringify(body)
  };
}
__name(respond, "respond");
function refuse(error) {
  return respond({
    statusCode: error.status,
    body: { error: { code: error.code, message: error.message, status: error.status } }
  });
}
__name(refuse, "refuse");
function isAuthorised(event) {
  const secret = (process.env.POSTCARD_FUNCTION_SECRET ?? "").trim();
  if (!secret) {
    logger2.error("POSTCARD_FUNCTION_SECRET is not set, so every request is refused.");
    return false;
  }
  const expected = Buffer.from(secret);
  const given = Buffer.from(event.headers?.[SECRET_HEADER] ?? "");
  return given.length === expected.length && (0, import_node_crypto2.timingSafeEqual)(given, expected);
}
__name(isAuthorised, "isAuthorised");
function createHandler(service) {
  return async (event) => {
    if (isDrawEvent(event)) {
      return respond(await service.serve({ ...event.params, background: true }));
    }
    if (!isFunctionUrlEvent(event)) {
      logger2.error("Refused an event that is neither a Function URL request nor a draw.");
      return refuse(new BadRequestError("The function answers Function URL requests and its own draws only."));
    }
    const method = event.requestContext.http.method;
    if (!isAuthorised(event)) {
      logger2.warn(`Refused ${method} ${event.rawPath} without the function secret.`);
      return refuse(new UnauthorizedError());
    }
    if (event.rawPath !== ROUTE) {
      return refuse(new RouteNotFoundError(event.rawPath));
    }
    const params = {
      ...event.queryStringParameters,
      __ow_method: method.toLowerCase()
    };
    return respond(await service.serve(params));
  };
}
__name(createHandler, "createHandler");
var handler = createHandler(
  new PostcardService({ context: CONTEXT, store: createS3, scheduler: createInvoker })
);
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  createHandler,
  handler
});
